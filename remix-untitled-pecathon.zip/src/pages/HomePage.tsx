import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Moon, ArrowRight } from 'lucide-react';
import { StarField } from '../components/StarField';
import { FallingLeaves } from '../components/FallingLeaves';
import { CelestialFactOfTheDay } from '../components/common/CelestialFactOfTheDay';
import { getLunarPhase, fetchMoonPhaseApiData, MoonPhaseApiResponse } from '../utils/lunarCycle';
import { playSuzuChime } from '../utils/soundEngine';
import { useCalmMode } from '../utils/calmMode';

/* ── Tarot Card Line-Art Illustrations in #D4A84B ──────────────────────── */

const WatchtowerSvg: React.FC = () => (
  <svg
    viewBox="0 0 160 160"
    className="w-full h-full"
    fill="none"
    stroke="#D4A84B"
    strokeWidth="1.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Background radiant aura */}
    <circle cx="80" cy="52" r="22" strokeDasharray="3 3" opacity="0.5" />
    <circle cx="80" cy="52" r="16" fill="#D4A84B" fillOpacity="0.1" />
    {/* Sun rays */}
    {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
      <line
        key={deg}
        x1={80 + 20 * Math.cos((deg * Math.PI) / 180)}
        y1={52 + 20 * Math.sin((deg * Math.PI) / 180)}
        x2={80 + 28 * Math.cos((deg * Math.PI) / 180)}
        y2={52 + 28 * Math.sin((deg * Math.PI) / 180)}
        opacity="0.8"
      />
    ))}
    {/* Serene face features */}
    <path d="M74 49 Q76 46 78 49" strokeWidth="1" />
    <path d="M82 49 Q84 46 86 49" strokeWidth="1" />
    <path d="M80 51 L80 55" strokeWidth="0.8" />
    <path d="M76 57 Q80 60 84 57" strokeWidth="1" />
    {/* Mountain ridges */}
    <path d="M15 135 L50 86 L85 135" opacity="0.65" />
    <path d="M60 135 L96 95 L145 135" opacity="0.55" />
    <path d="M35 110 L50 86 L65 110 Q50 102 35 110" fill="#D4A84B" fillOpacity="0.08" />
    {/* Beacon watchtower */}
    <line x1="72" y1="135" x2="75" y2="92" strokeWidth="1.4" />
    <line x1="88" y1="135" x2="85" y2="92" strokeWidth="1.4" />
    <line x1="73" y1="116" x2="87" y2="116" />
    <line x1="74" y1="104" x2="86" y2="104" />
    <rect x="73" y="87" width="14" height="6" rx="1" fill="#0A0A0F" stroke="#D4A84B" />
    {/* Celestial beacon light */}
    <path d="M80 85 Q82 78 80 74 Q78 78 80 85" fill="#D4A84B" fillOpacity="0.6" />
    <path d="M76 83 L68 78 M84 83 L92 78" opacity="0.6" />
    {/* 4-point sparkle stars */}
    <path d="M28 36 L29 39 L32 40 L29 41 L28 44 L27 41 L24 40 L27 39 Z" fill="#D4A84B" stroke="none" />
    <path d="M132 38 L133 41 L136 42 L133 43 L132 46 L131 43 L128 42 L131 41 Z" fill="#D4A84B" stroke="none" />
    <path d="M122 75 L122.5 77 L124.5 77.5 L122.5 78 L122 80 L121.5 78 L119.5 77.5 L121.5 77 Z" fill="#D4A84B" stroke="none" />
    <path d="M38 72 L38.5 74 L40.5 74.5 L38.5 75 L38 77 L37.5 75 L35.5 74.5 L37.5 74 Z" fill="#D4A84B" stroke="none" />
  </svg>
);

const CelestialScrollSvg: React.FC = () => (
  <svg
    viewBox="0 0 160 160"
    className="w-full h-full"
    fill="none"
    stroke="#D4A84B"
    strokeWidth="1.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Celestial orbit ring */}
    <circle cx="80" cy="70" r="44" strokeDasharray="2 3" opacity="0.4" />
    {/* Crescent Moon */}
    <path
      d="M74 38 A32 32 0 1 0 102 96 A25 25 0 1 1 74 38 Z"
      fill="#D4A84B"
      fillOpacity="0.12"
      stroke="#D4A84B"
      strokeWidth="1.4"
    />
    {/* Moon peaceful face */}
    <path d="M72 60 Q75 58 77 61" strokeWidth="0.9" />
    <path d="M78 66 Q75 68 74 70" strokeWidth="0.8" />
    <path d="M71 75 Q75 77 77 76" strokeWidth="0.9" />
    {/* Japanese emaki style clouds */}
    <path d="M22 86 Q33 78 45 84 Q57 76 70 82 Q80 88 90 86" strokeWidth="1.1" opacity="0.85" />
    <path d="M84 89 Q96 82 110 86 Q122 79 138 86" strokeWidth="1.1" opacity="0.85" />
    <path d="M32 95 Q46 89 58 93 Q70 97 84 93" strokeWidth="0.9" opacity="0.5" />
    {/* Sacred Scroll */}
    <rect x="52" y="112" width="56" height="22" rx="2" fill="#0A0A0F" stroke="#D4A84B" strokeWidth="1.3" />
    <path d="M50 110 Q52 123 50 136 M108 110 Q110 123 108 136" strokeWidth="1.6" />
    <line x1="60" y1="118" x2="100" y2="118" strokeDasharray="3 3" opacity="0.75" />
    <line x1="60" y1="124" x2="92" y2="124" strokeDasharray="3 3" opacity="0.75" />
    {/* Constellation nodes */}
    <circle cx="44" cy="46" r="1.5" fill="#D4A84B" stroke="none" />
    <circle cx="58" cy="36" r="1.5" fill="#D4A84B" stroke="none" />
    <circle cx="116" cy="44" r="1.5" fill="#D4A84B" stroke="none" />
    <circle cx="126" cy="56" r="1.5" fill="#D4A84B" stroke="none" />
    <line x1="44" y1="46" x2="58" y2="36" strokeDasharray="2 2" opacity="0.5" />
    <line x1="116" y1="44" x2="126" y2="56" strokeDasharray="2 2" opacity="0.5" />
    {/* 4-point sparkle stars */}
    <path d="M120 30 L121.5 33.5 L125 35 L121.5 36.5 L120 40 L118.5 36.5 L115 35 L118.5 33.5 Z" fill="#D4A84B" stroke="none" />
    <path d="M36 62 L37 64.5 L39.5 65.5 L37 66.5 L36 69 L35 66.5 L32.5 65.5 L35 64.5 Z" fill="#D4A84B" stroke="none" />
    <path d="M130 98 L130.5 100 L132.5 100.5 L130.5 101 L130 103 L129.5 101 L127.5 100.5 L129.5 100 Z" fill="#D4A84B" stroke="none" />
  </svg>
);

const SpiritLensSvg: React.FC = () => (
  <svg
    viewBox="0 0 160 160"
    className="w-full h-full"
    fill="none"
    stroke="#D4A84B"
    strokeWidth="1.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Concentric optical rings */}
    <circle cx="80" cy="80" r="50" strokeDasharray="3 3" opacity="0.4" />
    <circle cx="80" cy="80" r="40" strokeWidth="1.3" opacity="0.75" />
    <circle cx="80" cy="80" r="28" strokeWidth="1" />
    {/* Eyepiece / celestial eye aperture */}
    <path
      d="M40 80 Q80 46 120 80 Q80 114 40 80 Z"
      strokeWidth="1.4"
      fill="#D4A84B"
      fillOpacity="0.08"
    />
    <circle cx="80" cy="80" r="16" fill="#0A0A0F" stroke="#D4A84B" strokeWidth="1.5" />
    <circle cx="80" cy="80" r="7" fill="#D4A84B" stroke="none" />
    {/* Light refraction rays */}
    <line x1="28" y1="28" x2="70" y2="70" strokeDasharray="2 2" opacity="0.6" />
    <line x1="132" y1="28" x2="90" y2="70" strokeDasharray="2 2" opacity="0.6" />
    <line x1="80" y1="18" x2="80" y2="58" strokeDasharray="3 2" opacity="0.8" />
    <line x1="80" y1="102" x2="80" y2="142" strokeDasharray="3 2" opacity="0.8" />
    {/* Crosshairs & prism geometry */}
    <line x1="24" y1="80" x2="38" y2="80" strokeWidth="1.5" />
    <line x1="122" y1="80" x2="136" y2="80" strokeWidth="1.5" />
    <polygon points="80,30 124,104 36,104" strokeWidth="0.8" strokeDasharray="2 3" opacity="0.5" />
    {/* Sparkles */}
    <path d="M80 16 L81.5 20 L85 21.5 L81.5 23 L80 27 L78.5 23 L75 21.5 L78.5 20 Z" fill="#D4A84B" stroke="none" />
    <path d="M34 124 L35.5 127 L38.5 128 L35.5 129 L34 132 L32.5 129 L29.5 128 L32.5 127 Z" fill="#D4A84B" stroke="none" />
    <path d="M126 124 L127.5 127 L130.5 128 L127.5 129 L126 132 L124.5 129 L121.5 128 L124.5 127 Z" fill="#D4A84B" stroke="none" />
  </svg>
);

const DojoDashboardSvg: React.FC = () => (
  <svg
    viewBox="0 0 160 160"
    className="w-full h-full"
    fill="none"
    stroke="#D4A84B"
    strokeWidth="1.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Astrolabe outer ring with tick marks */}
    <circle cx="80" cy="80" r="50" strokeWidth="1.4" opacity="0.8" />
    <circle cx="80" cy="80" r="43" strokeDasharray="2 2" opacity="0.5" />
    {/* 8 Moon phases around the dial */}
    {/* Top: Full Moon */}
    <circle cx="80" cy="37" r="6" fill="#D4A84B" fillOpacity="0.45" stroke="#D4A84B" strokeWidth="1.2" />
    {/* Bottom: New Moon */}
    <circle cx="80" cy="123" r="6" fill="#0A0A0F" stroke="#D4A84B" strokeWidth="1.2" />
    {/* Left: First Quarter */}
    <path d="M37 74 A6 6 0 0 1 37 86 Z" fill="#D4A84B" fillOpacity="0.6" stroke="#D4A84B" strokeWidth="1.2" />
    <circle cx="37" cy="80" r="6" stroke="#D4A84B" strokeWidth="1.2" />
    {/* Right: Last Quarter */}
    <path d="M123 74 A6 6 0 0 0 123 86 Z" fill="#D4A84B" fillOpacity="0.6" stroke="#D4A84B" strokeWidth="1.2" />
    <circle cx="123" cy="80" r="6" stroke="#D4A84B" strokeWidth="1.2" />
    {/* Intermediate crescent moonlets */}
    <circle cx="49" cy="49" r="4" stroke="#D4A84B" opacity="0.75" />
    <circle cx="111" cy="49" r="4" stroke="#D4A84B" opacity="0.75" />
    <circle cx="49" cy="111" r="4" stroke="#D4A84B" opacity="0.75" />
    <circle cx="111" cy="111" r="4" stroke="#D4A84B" opacity="0.75" />
    {/* Sacred geometry dial */}
    <circle cx="80" cy="80" r="22" strokeWidth="1" />
    <line x1="80" y1="58" x2="80" y2="102" strokeWidth="0.8" opacity="0.6" />
    <line x1="58" y1="80" x2="102" y2="80" strokeWidth="0.8" opacity="0.6" />
    {/* Astrolabe star pivot */}
    <polygon points="80,72 82,78 88,80 82,82 80,88 78,82 72,80 78,78" fill="#D4A84B" stroke="none" />
    {/* Sparkles */}
    <path d="M22 26 L23.5 29.5 L27 31 L23.5 32.5 L22 36 L20.5 32.5 L17 31 L20.5 29.5 Z" fill="#D4A84B" stroke="none" />
    <path d="M138 26 L139.5 29.5 L143 31 L139.5 32.5 L138 36 L136.5 32.5 L133 31 L136.5 29.5 Z" fill="#D4A84B" stroke="none" />
  </svg>
);

const HonorPointsSvg: React.FC = () => (
  <svg
    viewBox="0 0 160 160"
    className="w-full h-full"
    fill="none"
    stroke="#D4A84B"
    strokeWidth="1.2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Japanese Mon ring */}
    <circle cx="80" cy="80" r="50" strokeWidth="1.4" opacity="0.8" />
    <circle cx="80" cy="80" r="44" strokeDasharray="2 3" opacity="0.5" />
    {/* Tsuba / Sun crest circular boundary */}
    <circle cx="80" cy="80" r="28" strokeWidth="1.2" fill="#D4A84B" fillOpacity="0.08" />
    {/* 8-fold sunburst blades */}
    {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => {
      const rad = (angle * Math.PI) / 180;
      const x1 = 80 + 12 * Math.cos(rad);
      const y1 = 80 + 12 * Math.sin(rad);
      const x2 = 80 + 38 * Math.cos(rad);
      const y2 = 80 + 38 * Math.sin(rad);
      return (
        <g key={angle}>
          <line x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth="1.4" opacity="0.9" />
          <circle cx={x2} cy={y2} r="2" fill="#D4A84B" stroke="none" />
        </g>
      );
    })}
    {/* Core crest */}
    <circle cx="80" cy="80" r="10" strokeWidth="1.5" fill="#0A0A0F" />
    <path d="M80 70 A10 10 0 0 1 85 85 A5 5 0 0 0 80 80" strokeWidth="1" fill="#D4A84B" opacity="0.75" />
    <path d="M70 85 A10 10 0 0 1 85 80 A5 5 0 0 0 80 80" strokeWidth="1" fill="#D4A84B" opacity="0.75" />
    {/* Outer radiating aura */}
    {[22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5].map((angle) => {
      const rad = (angle * Math.PI) / 180;
      const x1 = 80 + 44 * Math.cos(rad);
      const y1 = 80 + 44 * Math.sin(rad);
      const x2 = 80 + 52 * Math.cos(rad);
      const y2 = 80 + 52 * Math.sin(rad);
      return <line key={angle} x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth="0.9" opacity="0.6" />;
    })}
    {/* Sparkles */}
    <path d="M26 24 L27.5 27.5 L31 29 L27.5 30.5 L26 34 L24.5 30.5 L21 29 L24.5 27.5 Z" fill="#D4A84B" stroke="none" />
    <path d="M134 24 L135.5 27.5 L139 29 L135.5 30.5 L134 34 L132.5 30.5 L129 29 L132.5 27.5 Z" fill="#D4A84B" stroke="none" />
    <path d="M80 142 L81.5 145 L84.5 146 L81.5 147 L80 150 L78.5 147 L75.5 146 L78.5 145 Z" fill="#D4A84B" stroke="none" />
  </svg>
);

/* ── Tarot Deck Data ─────────────────────────────────────────────────────── */

interface TarotCardData {
  to: string;
  roman: string;
  kanji: string;
  title: string;
  sub: string;
  desc: string;
  Svg: React.FC;
}

const TAROT_CARDS: TarotCardData[] = [
  {
    to: '/watchtower',
    roman: 'I',
    kanji: '見張台',
    title: 'The Watchtower',
    sub: 'Stargazing Location Finder',
    desc: 'Find dark, clear-sky spots near you ranked by cloud cover, air quality and light pollution.',
    Svg: WatchtowerSvg,
  },
  {
    to: '/scroll',
    roman: 'II',
    kanji: '天文絵巻',
    title: 'The Celestial Scroll',
    sub: 'Space Event Tracker',
    desc: 'Meteor showers, eclipses, rocket launches and visible ISS passes for your location.',
    Svg: CelestialScrollSvg,
  },
  {
    to: '/lens',
    roman: 'III',
    kanji: '霊鏡',
    title: 'The Spirit Lens',
    sub: 'Astrophotography Restoration',
    desc: 'Upload a space photo and clean up noise and blur without inventing detail.',
    Svg: SpiritLensSvg,
  },
  {
    to: '/dojo',
    roman: 'IV',
    kanji: '天文道場',
    title: 'The Dojo Dashboard',
    sub: 'Before / After Visualization',
    desc: 'Compare original and restored images, zoom in, and inspect detected stars and galaxies.',
    Svg: DojoDashboardSvg,
  },
  {
    to: '/honor',
    roman: 'V',
    kanji: '武士道',
    title: 'Honor Points',
    sub: 'Progress & Ranks',
    desc: 'Earn ranks for observing events, visiting sites and restoring images.',
    Svg: HonorPointsSvg,
  },
];

const BASE_ROTATIONS = [-8, -4, 0, 4, 8];
const BASE_VERTICAL_OFFSETS = [6, 2, 0, 2, 6];

export const HomePage: React.FC = () => {
  const [calm] = useCalmMode();
  const [apiLunar, setApiLunar] = useState<MoonPhaseApiResponse | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [focusedIdx, setFocusedIdx] = useState<number | null>(null);

  useEffect(() => {
    fetchMoonPhaseApiData()
      .then((res) => setApiLunar(res))
      .catch(() => {
        /* falls back to local SunCalc ephemeris */
      });
  }, []);

  const lunar = getLunarPhase(new Date(), undefined, undefined, apiLunar);
  const activeIdx = hoveredIdx !== null ? hoveredIdx : focusedIdx;

  return (
    <div className="relative">
      {/* Decorative motion only on the home page, and never in calm mode */}
      {!calm && <FallingLeaves density={8} />}

      <section className="relative w-full pt-28 pb-12 px-4 sm:px-6 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/assets/images/rainy_temple_gate.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/85 to-[#0A0A0F]/92" />
        {!calm && <StarField starCount={110} />}

        <div className="relative z-10 max-w-3xl mx-auto text-center space-y-5">
          <p className="text-[11px] font-mono tracking-[0.25em] uppercase text-[#D4A84B]">
            月読の門 · Tsukuyomi Watch
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-[#F4EFE3] leading-[1.12]">
            Read the heavens <span className="text-[#D4A84B]">like a warrior.</span>
          </h1>
          <p className="font-sans text-sm sm:text-base text-[#F4EFE3]/80 max-w-xl mx-auto leading-relaxed">
            Find clear skies, track celestial events, and restore deep-space photos. Pick a tarot card below to begin.
          </p>

          {/* Tonight: quiet celestial status line */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#0E1326]/80 border border-[#D4A84B]/30 text-xs font-mono text-[#F4EFE3]/85 shadow-[0_4px_12px_rgba(0,0,0,0.5)]">
            <Moon className="w-3.5 h-3.5 text-[#D4A84B]" />
            <span>
              Tonight: {lunar.englishName} · {lunar.illuminationExact}% lit · moonrise {lunar.moonriseFormatted}
            </span>
          </div>
        </div>
      </section>

      {/* Main menu as TAROT CARD DECK */}
      <section aria-labelledby="menu-heading" className="relative max-w-6xl mx-auto px-4 sm:px-8 py-12">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-8 pb-3 border-b border-[#D4A84B]/20">
          <div>
            <h2 id="menu-heading" className="font-serif text-2xl sm:text-3xl font-bold text-[#F4EFE3]">
              Main menu
            </h2>
            <p className="font-mono text-xs uppercase tracking-widest text-[#D4A84B]/80 mt-1">
              Celestial Oracle Arcana · 天文託宣
            </p>
          </div>
          <span className="hidden sm:inline font-mono text-[11px] text-[#8E9BB5]/70">
            5 Arcana of Tsukuyomi
          </span>
        </div>

        {/* ── DESKTOP: Overlapping Fanned Tarot Deck (>= 1024px) ────────────────── */}
        {!calm && (
          <div className="hidden lg:flex items-center justify-center pt-8 pb-14 min-h-[460px] select-none">
            <div className="flex items-center justify-center">
              {TAROT_CARDS.map(({ to, roman, kanji, title, sub, desc, Svg }, idx) => {
                const isActive = activeIdx === idx;
                const baseRot = BASE_ROTATIONS[idx];
                const baseY = BASE_VERTICAL_OFFSETS[idx];

                // Neighbor displacement calculation:
                // If active card i is selected:
                // j < i: shifts left (-32px)
                // j > i: shifts right (+32px)
                let transformStyle = '';
                let zIndex = idx + 1;

                if (activeIdx !== null) {
                  if (isActive) {
                    transformStyle = 'translateY(-24px) rotate(0deg) scale(1.08)';
                    zIndex = 35;
                  } else if (idx < activeIdx) {
                    transformStyle = `translateX(-32px) translateY(${baseY}px) rotate(${baseRot}deg) scale(0.97)`;
                    zIndex = idx + 1;
                  } else {
                    transformStyle = `translateX(32px) translateY(${baseY}px) rotate(${baseRot}deg) scale(0.97)`;
                    zIndex = 10 - idx;
                  }
                } else {
                  transformStyle = `translateY(${baseY}px) rotate(${baseRot}deg) scale(1)`;
                  zIndex = idx === 2 ? 6 : (idx === 1 || idx === 3 ? 5 : 4);
                }

                return (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => playSuzuChime()}
                    onMouseEnter={() => setHoveredIdx(idx)}
                    onMouseLeave={() => setHoveredIdx(null)}
                    onFocus={() => setFocusedIdx(idx)}
                    onBlur={() => setFocusedIdx(null)}
                    aria-label={`${roman}: ${title} - ${sub}`}
                    style={{
                      transform: transformStyle,
                      zIndex,
                    }}
                    className={`tarot-card group relative -mx-4 shrink-0 w-[220px] aspect-[2/3.4] rounded-[14px] p-2 bg-gradient-to-b from-[#0E1326] via-[#0A0A0F] to-[#0A0A0F] border transition-all duration-400 ease-[cubic-bezier(0.16,1,0.3,1)] focus-visible:outline-none cursor-pointer ${
                      isActive
                        ? 'border-[#D4A84B] shadow-[0_20px_45px_-10px_rgba(212,168,75,0.45),0_0_25px_rgba(212,168,75,0.25)]'
                        : 'border-[#D4A84B]/50 hover:border-[#D4A84B] shadow-[0_12px_24px_-8px_rgba(0,0,0,0.7)]'
                    }`}
                  >
                    {/* Top & bottom border star/diamond ornaments */}
                    <div
                      aria-hidden="true"
                      className="absolute -top-2 left-1/2 -translate-x-1/2 px-1 bg-[#0E1326] text-[#D4A84B] text-[10px] leading-none select-none z-20 pointer-events-none"
                    >
                      ✦
                    </div>
                    <div
                      aria-hidden="true"
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-1 bg-[#0A0A0F] text-[#D4A84B] text-[10px] leading-none select-none z-20 pointer-events-none"
                    >
                      ✦
                    </div>

                    {/* Inner gold border with corner inset */}
                    <div className="relative w-full h-full rounded-[10px] border border-[#D4A84B]/35 p-3 flex flex-col justify-between overflow-hidden">
                      {/* Corner subtle bracket lines */}
                      <div className="absolute top-1 left-1 w-2 h-2 border-t border-l border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute top-1 right-1 w-2 h-2 border-t border-r border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute bottom-1 left-1 w-2 h-2 border-b border-l border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute bottom-1 right-1 w-2 h-2 border-b border-r border-[#D4A84B]/60 pointer-events-none" />

                      {/* Header: Roman Numeral & Japanese Kanji */}
                      <div className="flex items-center justify-between text-[#D4A84B]/90 pt-0.5">
                        <span className="font-serif font-semibold text-xs tracking-widest">{roman}</span>
                        <span className="font-kanji text-[11px] text-[#8E9BB5]">{kanji}</span>
                      </div>

                      {/* Middle: Gold Line-Art Illustration */}
                      <div className="my-auto py-2 w-28 h-28 mx-auto flex items-center justify-center">
                        <Svg />
                      </div>

                      {/* Footer: Title, Subtitle, and Slide-in Description */}
                      <div className="text-center pb-0.5">
                        <h3 className="font-serif font-bold text-[15px] leading-tight text-[#F4EFE3] group-hover:text-[#F4EFE3]">
                          {title}
                        </h3>
                        <p className="font-mono text-[9px] uppercase tracking-wider text-[#D4A84B]/80 mt-1">
                          {sub}
                        </p>

                        {/* Longer description revealed on hover/focus */}
                        <div
                          className={`transition-all duration-300 ease-out overflow-hidden text-left ${
                            isActive
                              ? 'opacity-100 max-h-28 mt-2.5 pt-2 border-t border-[#D4A84B]/25'
                              : 'opacity-0 max-h-0 mt-0 pointer-events-none'
                          }`}
                        >
                          <p className="font-sans text-[10.5px] text-[#F4EFE3]/80 leading-relaxed text-center">
                            {desc}
                          </p>
                          <div className="mt-1.5 flex items-center justify-center gap-1 text-[10px] font-semibold text-[#D4A84B]">
                            <span>Consult</span>
                            <ArrowRight className="w-3 h-3" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* ── MOBILE & TABLET: Horizontal Scroll-Snap Carousel (< 1024px) ───────── */}
        {!calm && (
          <div className="lg:hidden">
            <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 pb-6 px-4 no-scrollbar -mx-4 sm:-mx-8">
              {TAROT_CARDS.map(({ to, roman, kanji, title, sub, desc, Svg }, idx) => {
                const isActive = activeIdx === idx;
                return (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => playSuzuChime()}
                    onMouseEnter={() => setHoveredIdx(idx)}
                    onMouseLeave={() => setHoveredIdx(null)}
                    onFocus={() => setFocusedIdx(idx)}
                    onBlur={() => setFocusedIdx(null)}
                    aria-label={`${roman}: ${title} - ${sub}`}
                    className={`tarot-card snap-center shrink-0 w-[220px] aspect-[2/3.4] rounded-[14px] p-2 bg-gradient-to-b from-[#0E1326] via-[#0A0A0F] to-[#0A0A0F] border transition-all duration-300 focus-visible:outline-none cursor-pointer ${
                      isActive
                        ? 'border-[#D4A84B] shadow-[0_12px_30px_-6px_rgba(212,168,75,0.35)]'
                        : 'border-[#D4A84B]/50 hover:border-[#D4A84B] shadow-[0_8px_18px_-4px_rgba(0,0,0,0.6)]'
                    }`}
                  >
                    {/* Top & bottom ornaments */}
                    <div
                      aria-hidden="true"
                      className="absolute -top-2 left-1/2 -translate-x-1/2 px-1 bg-[#0E1326] text-[#D4A84B] text-[10px] leading-none select-none z-20 pointer-events-none"
                    >
                      ✦
                    </div>
                    <div
                      aria-hidden="true"
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-1 bg-[#0A0A0F] text-[#D4A84B] text-[10px] leading-none select-none z-20 pointer-events-none"
                    >
                      ✦
                    </div>

                    <div className="relative w-full h-full rounded-[10px] border border-[#D4A84B]/35 p-3 flex flex-col justify-between overflow-hidden">
                      <div className="absolute top-1 left-1 w-2 h-2 border-t border-l border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute top-1 right-1 w-2 h-2 border-t border-r border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute bottom-1 left-1 w-2 h-2 border-b border-l border-[#D4A84B]/60 pointer-events-none" />
                      <div className="absolute bottom-1 right-1 w-2 h-2 border-b border-r border-[#D4A84B]/60 pointer-events-none" />

                      <div className="flex items-center justify-between text-[#D4A84B]/90 pt-0.5">
                        <span className="font-serif font-semibold text-xs tracking-widest">{roman}</span>
                        <span className="font-kanji text-[11px] text-[#8E9BB5]">{kanji}</span>
                      </div>

                      <div className="my-auto py-2 w-28 h-28 mx-auto flex items-center justify-center">
                        <Svg />
                      </div>

                      <div className="text-center pb-0.5">
                        <h3 className="font-serif font-bold text-[15px] leading-tight text-[#F4EFE3]">
                          {title}
                        </h3>
                        <p className="font-mono text-[9px] uppercase tracking-wider text-[#D4A84B]/80 mt-1">
                          {sub}
                        </p>
                        <p className="font-sans text-[10.5px] text-[#F4EFE3]/75 leading-relaxed text-center mt-2 line-clamp-2">
                          {desc}
                        </p>
                        <div className="mt-2 flex items-center justify-center gap-1 text-[10px] font-semibold text-[#D4A84B]">
                          <span>Open</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
            <p className="text-center font-mono text-[10.5px] text-[#8E9BB5]/60 mt-2">
              ← Swipe sideways to explore tarot deck →
            </p>
          </div>
        )}

        {/* ── CALM MODE / REDUCED MOTION: Clean Responsive Grid ─────────────────── */}
        {calm && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5 justify-items-center">
            {TAROT_CARDS.map(({ to, roman, kanji, title, sub, desc, Svg }) => (
              <Link
                key={to}
                to={to}
                onClick={() => playSuzuChime()}
                aria-label={`${roman}: ${title} - ${sub}`}
                className="tarot-card relative w-[220px] aspect-[2/3.4] rounded-[14px] p-2 bg-gradient-to-b from-[#0E1326] via-[#0A0A0F] to-[#0A0A0F] border border-[#D4A84B]/40 hover:border-[#D4A84B] focus-visible:border-[#D4A84B] shadow-[0_4px_12px_rgba(0,0,0,0.5)] hover:shadow-[0_0_15px_rgba(212,168,75,0.25)] transition-colors focus-visible:outline-none"
              >
                <div
                  aria-hidden="true"
                  className="absolute -top-2 left-1/2 -translate-x-1/2 px-1 bg-[#0E1326] text-[#D4A84B] text-[10px] leading-none select-none z-20"
                >
                  ✦
                </div>
                <div
                  aria-hidden="true"
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-1 bg-[#0A0A0F] text-[#D4A84B] text-[10px] leading-none select-none z-20"
                >
                  ✦
                </div>

                <div className="relative w-full h-full rounded-[10px] border border-[#D4A84B]/35 p-3 flex flex-col justify-between">
                  <div className="flex items-center justify-between text-[#D4A84B]/90 pt-0.5">
                    <span className="font-serif font-semibold text-xs tracking-widest">{roman}</span>
                    <span className="font-kanji text-[11px] text-[#8E9BB5]">{kanji}</span>
                  </div>

                  <div className="my-auto py-2 w-28 h-28 mx-auto flex items-center justify-center">
                    <Svg />
                  </div>

                  <div className="text-center pb-0.5">
                    <h3 className="font-serif font-bold text-[15px] leading-tight text-[#F4EFE3]">
                      {title}
                    </h3>
                    <p className="font-mono text-[9px] uppercase tracking-wider text-[#D4A84B]/80 mt-1">
                      {sub}
                    </p>
                    <p className="font-sans text-[10.5px] text-[#8E9BB5] leading-relaxed text-center mt-2">
                      {desc}
                    </p>
                    <div className="mt-2.5 flex items-center justify-center gap-1 text-[10px] font-semibold text-[#D4A84B]">
                      <span>Open</span>
                      <ArrowRight className="w-3 h-3" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="relative max-w-4xl mx-auto px-4 sm:px-8 pb-16">
        <CelestialFactOfTheDay />
      </section>
    </div>
  );
};
