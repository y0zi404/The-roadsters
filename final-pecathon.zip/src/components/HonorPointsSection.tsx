import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Award,
  Sparkles,
  Shield,
  Flame,
  Bell,
  Eye,
  Compass,
  CheckCircle2,
  ScrollText,
  Download,
  Filter,
  Calendar,
} from 'lucide-react';
import {
  HONOR_RANKS,
  HonorState,
  HonorActivityEntry,
  ComputedBadge,
  getHonorState,
  subscribeToHonorChanges,
  getRankForPoints,
  computeBadges,
  getUnlockedBadgesWithDates,
  awardAlertSetPoints,
  awardEventObservedPoints,
  awardVisitTopSpotPoints,
  awardImageRestoredPoints,
} from '../utils/honorSystem';
import { playSuzuChime, playKotoNote } from '../utils/soundEngine';

export const HonorPointsSection: React.FC = () => {
  const [honorState, setHonorState] = useState<HonorState>(() => getHonorState());
  const [selectedBadgeId, setSelectedBadgeId] = useState<string>('vigil-keeper');
  const [actionToast, setActionToast] = useState<string | null>(null);

  useEffect(() => {
    setHonorState(getHonorState());
    return subscribeToHonorChanges((nextState) => {
      setHonorState(nextState);
    });
  }, []);

  const {
    currentRank,
    nextRank,
    progressPercent,
    pointsNeededForNextRank,
  } = getRankForPoints(honorState.points);

  const badges = computeBadges(honorState);
  const unlockedCount = badges.filter((b) => b.unlocked).length;

  // Overall progress bar across the 4 ranks (0 -> 3000+)
  const overallScalePct = Math.min(100, Math.round((honorState.points / 3000) * 100));

  const triggerHonorFeedback = (msg: string) => {
    setActionToast(msg);
    setTimeout(() => setActionToast(null), 4000);
  };

  const handleQuickAwardAlert = () => {
    playSuzuChime();
    const id = `scroll-vigil-${honorState.alertsSetIds.length + 1}`;
    const res = awardAlertSetPoints(id, `Lunar Ephemeris Vigil #${honorState.alertsSetIds.length + 1}`);
    if (res.awarded) {
      triggerHonorFeedback(`+${res.pointsAdded} Honor Points · Night Watch Alert Armed`);
    }
  };

  const handleQuickAwardObserve = () => {
    playKotoNote(587.33, 1.1);
    const id = `observed-celestial-${honorState.observedEventIds.length + 1}`;
    const res = awardEventObservedPoints(
      id,
      `Celestial Observation Log #${honorState.observedEventIds.length + 1}`
    );
    if (res.awarded) {
      triggerHonorFeedback(`+${res.pointsAdded} Honor Points · Celestial Event Marked Observed`);
    }
  };

  const handleQuickAwardVisitSpot = () => {
    playKotoNote(523.25, 1.1);
    const id = `sanctuary-peak-${honorState.visitedSpotIds.length + 1}`;
    const res = awardVisitTopSpotPoints(
      id,
      `Dark-Sky Peak Sanctuary #${honorState.visitedSpotIds.length + 1}`,
      94
    );
    if (res.awarded) {
      triggerHonorFeedback(`+${res.pointsAdded} Honor Points · Top-Rated Sanctuary Visited`);
    }
  };

  const handleQuickAwardRestore = () => {
    playKotoNote(659.25, 1.3);
    const res = awardImageRestoredPoints(
      `Deep-Sky Plate #${honorState.restoredCount + 1} (RL Deconvolution)`
    );
    if (res.awarded) {
      triggerHonorFeedback(`+${res.pointsAdded} Honor Points · Faithful Astro-Restoration Logged`);
    }
  };

  const renderCrestSvg = (type: ComputedBadge['svgType'], unlocked: boolean) => {
    const strokeColor = unlocked ? '#D4A84B' : '#8E9BB5';
    switch (type) {
      case 'moon':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="26" stroke={strokeColor} strokeWidth="1.5" strokeDasharray="3 3" />
            <path
              d="M36 16C26 18 20 28 24 38C27 45 35 48 42 45C33 49 21 45 17 35C13 25 18 14 28 11C31 10 34 13 36 16Z"
              fill={strokeColor}
              fillOpacity="0.85"
            />
          </svg>
        );
      case 'meteor':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="26" stroke={strokeColor} strokeWidth="1.5" />
            <path d="M15 45L45 15M25 45L45 25M15 35L35 15" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <circle cx="20" cy="40" r="4" fill="#B3202A" />
          </svg>
        );
      case 'watchtower':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="26" stroke={strokeColor} strokeWidth="1.5" />
            <path d="M12 44L30 16L48 44H12Z" stroke={strokeColor} strokeWidth="1.8" fill={strokeColor} fillOpacity="0.2" />
            <circle cx="30" cy="13" r="3" fill="#B3202A" />
          </svg>
        );
      case 'nebula':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="26" stroke={strokeColor} strokeWidth="1.5" />
            <ellipse cx="30" cy="30" rx="18" ry="8" transform="rotate(30 30 30)" stroke={strokeColor} strokeWidth="1.5" />
            <ellipse cx="30" cy="30" rx="18" ry="8" transform="rotate(-30 30 30)" stroke={strokeColor} strokeWidth="1.5" />
            <circle cx="30" cy="30" r="4" fill={strokeColor} />
          </svg>
        );
      case 'eclipse':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="24" stroke="#B3202A" strokeWidth="2" />
            <circle cx="30" cy="30" r="16" fill="#0A0A0F" stroke={strokeColor} strokeWidth="2" />
          </svg>
        );
      case 'shogun':
        return (
          <svg className="w-12 h-12" viewBox="0 0 60 60" fill="none">
            <circle cx="30" cy="30" r="26" stroke={strokeColor} strokeWidth="2" />
            <polygon
              points="30,10 35,23 49,23 38,31 42,45 30,37 18,45 22,31 11,23 25,23"
              stroke={strokeColor}
              strokeWidth="1.5"
              fill={unlocked ? '#D4A84B' : 'none'}
              fillOpacity="0.35"
            />
          </svg>
        );
    }
  };

  return (
    <section
      id="honor"
      className="relative py-24 px-4 sm:px-8 max-w-7xl mx-auto border-t border-[#D4A84B]/20"
    >
      {/* Chapter 05 Header */}
      <div className="border-b border-[#D4A84B]/25 pb-6 mb-10">
        <div className="flex items-center space-x-2 text-xs font-mono tracking-[0.25em] uppercase text-[#D4A84B]">
          <span>05. WAY OF THE ASTRONOMER · 天文武士道</span>
        </div>

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mt-2">
          <div>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-[#F4EFE3] text-glow-moon">
              Honor Points & Warrior Crests
            </h2>
            <p className="font-sans text-xs sm:text-sm text-[#8E9BB5] mt-1 max-w-2xl leading-relaxed">
              Ascend through the four Shogunate ranks (<span className="text-[#F4EFE3]">Ashigaru</span>,{' '}
              <span className="text-[#F4EFE3]">Samurai</span>,{' '}
              <span className="text-[#F4EFE3]">Daimyo</span>,{' '}
              <span className="text-[#D4A84B]">Shogun</span>) by setting alerts, observing celestial events, visiting top-rated sanctuaries, and restoring space captures. Persisted in localStorage.
            </p>
          </div>

          <div className="flex items-center space-x-3 font-mono text-xs tabular-nums">
            <span className="px-3.5 py-1.5 rounded-xl bg-[#0E1326] border border-[#D4A84B]/50 text-[#D4A84B] font-bold">
              UNLOCKED CRESTS: {unlockedCount} / {badges.length}
            </span>
          </div>
        </div>
      </div>

      {/* Live Toast Feedback Banner */}
      {actionToast && (
        <div className="mb-6 p-3.5 rounded-xl bg-[#D4A84B]/15 border border-[#D4A84B] flex items-center justify-between text-xs font-mono text-[#F4EFE3] shadow-lg">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-[#D4A84B] shrink-0" />
            <span>{actionToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionToast(null)}
            className="text-[#8E9BB5] hover:text-[#F4EFE3] ml-3 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Progression Banner & 4-Rank Stepper */}
      <div className="bg-gradient-to-br from-[#0E1326] via-[#151B38]/60 to-[#0A0A0F] border border-[#D4A84B]/50 rounded-3xl p-6 sm:p-10 mb-10 shadow-[0_0_35px_rgba(212,168,75,0.18)] relative overflow-hidden">
        {/* Subtle Background Kanji Watermark */}
        <span className="absolute -right-6 -bottom-10 font-kanji text-[140px] text-[#F4EFE3]/[0.03] select-none pointer-events-none">
          {currentRank.kanji}
        </span>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          {/* Left: Current Rank Emblem & Points Readout (5 cols) */}
          <div className="lg:col-span-5 flex items-center space-x-5">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#B3202A]/20 border-2 border-[#D4A84B] flex flex-col items-center justify-center shrink-0 shadow-[0_0_25px_rgba(212,168,75,0.4)]">
              <span className="font-kanji text-2xl sm:text-3xl font-bold text-[#D4A84B]">
                {currentRank.kanji}
              </span>
              <span className="text-[9px] font-mono uppercase tracking-widest text-[#F4EFE3] mt-0.5">
                {currentRank.name.toUpperCase()}
              </span>
            </div>

            <div className="space-y-1">
              <span className="text-xs font-mono uppercase tracking-widest text-[#D4A84B] block">
                CURRENT WARRIOR RANK
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#F4EFE3]">
                {currentRank.name} · {currentRank.kanji}
              </h3>
              <p className="font-sans text-xs text-[#8E9BB5]">{currentRank.subtitle}</p>
              <div className="flex items-center space-x-2 text-sm font-mono text-[#8E9BB5] pt-1 tabular-nums">
                <Flame className="w-4 h-4 text-[#B3202A]" />
                <span>Total Honor:</span>
                <span className="text-[#D4A84B] font-bold text-lg">
                  {honorState.points.toLocaleString()} PTS
                </span>
              </div>
            </div>
          </div>

          {/* Right: 4-Tier Rank Progression Bar (Ashigaru -> Samurai -> Daimyo -> Shogun) (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* 4-Step Rank Stepper Header */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono tabular-nums">
              {HONOR_RANKS.map((tier) => {
                const isReached = honorState.points >= tier.minPoints;
                const isCurrent = currentRank.name === tier.name;
                return (
                  <div
                    key={tier.name}
                    className={`p-2.5 rounded-xl border transition-all ${
                      isCurrent
                        ? 'bg-[#151B38] border-[#D4A84B] shadow-[0_0_15px_rgba(212,168,75,0.3)]'
                        : isReached
                        ? 'bg-[#0E1326]/90 border-[#D4A84B]/50'
                        : 'bg-[#0A0A0F]/60 border-[#151B38] opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`font-bold ${
                          isCurrent
                            ? 'text-[#D4A84B]'
                            : isReached
                            ? 'text-[#F4EFE3]'
                            : 'text-[#8E9BB5]'
                        }`}
                      >
                        {tier.name}
                      </span>
                      <span className="font-kanji text-[11px] text-[#D4A84B]">{tier.kanji}</span>
                    </div>
                    <span className="text-[10px] text-[#8E9BB5] block mt-0.5">
                      {tier.minPoints.toLocaleString()} PTS
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Next Rank Tier Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-mono tabular-nums">
                <span className="text-[#D4A84B] font-bold uppercase tracking-wider">
                  {nextRank
                    ? `PROGRESS TO ${nextRank.name.toUpperCase()} (${nextRank.kanji}): ${progressPercent}%`
                    : 'SUPREME SHOGUNATE RANK ACHIEVED (100%)'}
                </span>
                <span className="text-[#F4EFE3]">
                  {nextRank
                    ? `${pointsNeededForNextRank.toLocaleString()} PTS TO ${nextRank.name.toUpperCase()}`
                    : `${honorState.points.toLocaleString()} / 3,000+ PTS`}
                </span>
              </div>

              <div className="w-full h-4 bg-[#0A0A0F] rounded-full overflow-hidden border border-[#151B38] p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-[#B3202A] via-[#D4A84B] to-[#F4EFE3] rounded-full transition-all duration-700 shadow-[0_0_15px_rgba(212,168,75,0.6)]"
                  style={{ width: `${nextRank ? progressPercent : overallScalePct}%` }}
                />
              </div>
            </div>

            {/* Counter Pills for the 4 Honor Actions */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px] tabular-nums">
              <div className="px-3 py-2 rounded-xl bg-[#0A0A0F]/80 border border-[#151B38] flex items-center justify-between">
                <span className="text-[#8E9BB5]">Alerts Set</span>
                <span className="text-[#D4A84B] font-bold">{honorState.alertsSetIds.length}</span>
              </div>
              <div className="px-3 py-2 rounded-xl bg-[#0A0A0F]/80 border border-[#151B38] flex items-center justify-between">
                <span className="text-[#8E9BB5]">Observed</span>
                <span className="text-[#D4A84B] font-bold">{honorState.observedEventIds.length}</span>
              </div>
              <div className="px-3 py-2 rounded-xl bg-[#0A0A0F]/80 border border-[#151B38] flex items-center justify-between">
                <span className="text-[#8E9BB5]">Spots Visited</span>
                <span className="text-[#D4A84B] font-bold">{honorState.visitedSpotIds.length}</span>
              </div>
              <div className="px-3 py-2 rounded-xl bg-[#0A0A0F]/80 border border-[#151B38] flex items-center justify-between">
                <span className="text-[#8E9BB5]">Restorations</span>
                <span className="text-[#D4A84B] font-bold">{honorState.restoredCount}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Earn Honor Points Action Bar (Connected directly to localStorage Honor Engine) */}
      <div className="bg-[#0E1326] border border-[#D4A84B]/35 rounded-2xl p-5 mb-10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#151B38] pb-3">
          <div>
            <span className="text-[10px] font-mono text-[#D4A84B] uppercase tracking-widest font-bold block">
              FOUR PATHS OF ASTRONOMICAL HONOR · 武功の四道
            </span>
            <p className="font-sans text-xs text-[#8E9BB5] mt-0.5">
              Points are automatically awarded across the Watchtower, Celestial Scroll, and Spirit Lens—or log a field deed below:
            </p>
          </div>
          <span className="font-mono text-[11px] text-[#D4A84B] tabular-nums">
            LOCALSTORAGE SYNC ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
          <button
            type="button"
            onClick={handleQuickAwardAlert}
            className="p-3.5 rounded-xl bg-[#0A0A0F] hover:bg-[#151B38] border border-[#151B38] hover:border-[#D4A84B] transition-all flex items-center justify-between group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-2.5">
              <Bell className="w-4 h-4 text-[#D4A84B] shrink-0" />
              <div>
                <span className="text-[#F4EFE3] font-bold block group-hover:text-[#D4A84B]">
                  Set Ephemeris Alert
                </span>
                <span className="text-[10px] text-[#8E9BB5]">Celestial Scroll</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-[#D4A84B]/20 text-[#D4A84B] font-bold tabular-nums">
              +75
            </span>
          </button>

          <button
            type="button"
            onClick={handleQuickAwardObserve}
            className="p-3.5 rounded-xl bg-[#0A0A0F] hover:bg-[#151B38] border border-[#151B38] hover:border-[#D4A84B] transition-all flex items-center justify-between group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-2.5">
              <Eye className="w-4 h-4 text-[#D4A84B] shrink-0" />
              <div>
                <span className="text-[#F4EFE3] font-bold block group-hover:text-[#D4A84B]">
                  Mark Event Observed
                </span>
                <span className="text-[10px] text-[#8E9BB5]">Imperial Sighting</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-[#D4A84B]/20 text-[#D4A84B] font-bold tabular-nums">
              +150
            </span>
          </button>

          <button
            type="button"
            onClick={handleQuickAwardVisitSpot}
            className="p-3.5 rounded-xl bg-[#0A0A0F] hover:bg-[#151B38] border border-[#151B38] hover:border-[#D4A84B] transition-all flex items-center justify-between group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-2.5">
              <Compass className="w-4 h-4 text-[#D4A84B] shrink-0" />
              <div>
                <span className="text-[#F4EFE3] font-bold block group-hover:text-[#D4A84B]">
                  Visit Top-Rated Spot
                </span>
                <span className="text-[10px] text-[#8E9BB5]">Watchtower Sanctuary</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-[#D4A84B]/20 text-[#D4A84B] font-bold tabular-nums">
              +125
            </span>
          </button>

          <button
            type="button"
            onClick={handleQuickAwardRestore}
            className="p-3.5 rounded-xl bg-[#0A0A0F] hover:bg-[#151B38] border border-[#151B38] hover:border-[#D4A84B] transition-all flex items-center justify-between group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-2.5">
              <Sparkles className="w-4 h-4 text-[#D4A84B] shrink-0" />
              <div>
                <span className="text-[#F4EFE3] font-bold block group-hover:text-[#D4A84B]">
                  Restore Space Capture
                </span>
                <span className="text-[10px] text-[#8E9BB5]">Spirit Lens Deconvolve</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-[#D4A84B]/20 text-[#D4A84B] font-bold tabular-nums">
              +200
            </span>
          </button>
        </div>
      </div>

      {/* Warrior Crests / Badges Grid (6 Dynamic Badges) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {badges.map((badge) => {
          const isSelected = selectedBadgeId === badge.id;
          const pct = Math.min(
            100,
            Math.round((badge.progressCurrent / Math.max(1, badge.progressTarget)) * 100)
          );

          return (
            <div
              key={badge.id}
              onClick={() => {
                playSuzuChime();
                setSelectedBadgeId(badge.id);
              }}
              className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-4 ${
                badge.unlocked
                  ? isSelected
                    ? 'bg-[#0E1326] border-[#D4A84B] shadow-[0_0_25px_rgba(212,168,75,0.3)] scale-[1.01]'
                    : 'bg-[#0E1326]/80 border-[#151B38] hover:border-[#D4A84B]/60'
                  : 'bg-[#0A0A0F]/60 border-[#151B38]/60 opacity-75 hover:opacity-100'
              }`}
            >
              <div className="flex items-start space-x-4">
                {/* Kamon SVG Crest */}
                <div className="p-3 rounded-2xl bg-[#0A0A0F] border border-[#151B38] shrink-0 flex items-center justify-center">
                  {renderCrestSvg(badge.svgType, badge.unlocked)}
                </div>

                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] font-mono tracking-widest uppercase px-2 py-0.5 rounded bg-[#151B38] text-[#D4A84B] font-bold">
                      {badge.tier}
                    </span>
                    {badge.unlocked ? (
                      <span className="text-[10px] font-mono text-[#34D399] flex items-center space-x-1 font-bold">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>UNLOCKED</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono text-[#8E9BB5]">LOCKED</span>
                    )}
                  </div>

                  <h4 className="font-serif text-lg font-bold text-[#F4EFE3] pt-1 truncate">
                    {badge.name}
                  </h4>
                  <span className="font-kanji text-xs text-[#D4A84B] block">{badge.kanji}</span>
                  <p className="font-sans text-xs text-[#8E9BB5] leading-relaxed pt-1">
                    {badge.description}
                  </p>
                </div>
              </div>

              {/* Badge Requirement & Progress Bar */}
              <div className="space-y-1.5 pt-2 border-t border-[#151B38] font-mono text-[10px] tabular-nums">
                <div className="flex items-center justify-between">
                  <span className="text-[#8E9BB5]">Requirement</span>
                  <span className={badge.unlocked ? 'text-[#D4A84B] font-bold' : 'text-[#F4EFE3]'}>
                    {badge.requirementText}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#0A0A0F] rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      badge.unlocked ? 'bg-[#D4A84B]' : 'bg-[#8E9BB5]/50'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Imperial Honor Ledger - Paginated Chronicle */}
      <AchievementHistory page="honor" title="Imperial Honor Ledger · 勲功記録" className="mt-4" />
    </section>
  );
};

export interface AchievementHistoryProps {
  page: 'watchtower' | 'scroll' | 'honor';
  title?: string;
  className?: string;
}

export const AchievementHistory: React.FC<AchievementHistoryProps> = ({
  page,
  title,
  className = '',
}) => {
  const [honorState, setHonorState] = useState<HonorState>(() => getHonorState());
  const [filter, setFilter] = useState<string>('All');
  const [visibleLimit, setVisibleLimit] = useState<number>(10);

  useEffect(() => {
    setHonorState(getHonorState());
    return subscribeToHonorChanges((next) => {
      setHonorState(next);
    });
  }, []);

  const unlockedBadges = getUnlockedBadgesWithDates();

  // Badges related to this page
  const pageBadges = useMemo(() => {
    if (page === 'watchtower') {
      return unlockedBadges.filter((b) => b.id === 'summit-pilgrim' || b.id === 'shogun-ascendant');
    }
    if (page === 'scroll') {
      return unlockedBadges.filter(
        (b) => b.id === 'vigil-keeper' || b.id === 'meteor-ronin' || b.id === 'eclipse-oracle'
      );
    }
    return unlockedBadges;
  }, [page, unlockedBadges]);

  // Page-relevant actions
  const pageEntries = useMemo(() => {
    const list = honorState.history || [];
    if (page === 'watchtower') {
      return list.filter((e) => e.type === 'SPOT_VISITED');
    }
    if (page === 'scroll') {
      return list.filter((e) => e.type === 'ALERT_SET' || e.type === 'EVENT_OBSERVED');
    }
    return list;
  }, [honorState.history, page]);

  const totalDeeds = pageEntries.length;
  const totalPoints = pageEntries.reduce((sum, e) => sum + e.points, 0);

  // Filter chips available for this page
  const filterOptions = useMemo(() => {
    if (page === 'watchtower') {
      return ['All', 'Top rated 80+'];
    }
    if (page === 'scroll') {
      return ['All', 'Alerts set', 'Observed'];
    }
    return ['All', 'Alerts', 'Observed', 'Sanctuaries', 'Restorations'];
  }, [page]);

  // Apply active filter
  const filteredEntries = useMemo(() => {
    return pageEntries.filter((entry) => {
      if (filter === 'All') return true;
      if (page === 'watchtower') {
        if (filter === 'Top rated 80+') {
          return entry.meta?.honorScore !== undefined && entry.meta.honorScore >= 80;
        }
      }
      if (page === 'scroll') {
        if (filter === 'Alerts set') return entry.type === 'ALERT_SET';
        if (filter === 'Observed') return entry.type === 'EVENT_OBSERVED';
      }
      if (page === 'honor') {
        if (filter === 'Alerts') return entry.type === 'ALERT_SET';
        if (filter === 'Observed') return entry.type === 'EVENT_OBSERVED';
        if (filter === 'Sanctuaries') return entry.type === 'SPOT_VISITED';
        if (filter === 'Restorations') return entry.type === 'IMAGE_RESTORED';
      }
      return true;
    });
  }, [pageEntries, filter, page]);

  // Group by Month (newest month first)
  const groupedByMonth = useMemo(() => {
    const visibleEntries = filteredEntries.slice(0, visibleLimit);
    const groups: { monthKey: string; monthLabel: string; entries: HonorActivityEntry[] }[] = [];
    const groupMap = new Map<string, HonorActivityEntry[]>();

    visibleEntries.forEach((entry) => {
      const d = new Date(entry.timestamp);
      const key = !isNaN(d.getTime())
        ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
        : 'other';
      const label = !isNaN(d.getTime())
        ? d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
        : 'Chronicle';

      if (!groupMap.has(key)) {
        groupMap.set(key, []);
        groups.push({ monthKey: key, monthLabel: label, entries: groupMap.get(key)! });
      }
      groupMap.get(key)!.push(entry);
    });

    return groups;
  }, [filteredEntries, visibleLimit]);

  const handleExportJson = () => {
    const dataBlob = new Blob([JSON.stringify(pageEntries, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(dataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tsukuyomi-${page}-achievement-history.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const emptyHint =
    page === 'watchtower'
      ? 'Visit a stargazing spot to earn your first honor.'
      : page === 'scroll'
      ? 'Set an alert or observe a celestial event to earn your first honor.'
      : 'Perform deeds across the realm to build your celestial honor.';

  return (
    <div
      className={`bg-[#0E1326] border border-[#D4A84B]/40 rounded-2xl p-5 sm:p-7 shadow-[0_0_30px_rgba(212,168,75,0.12)] space-y-6 ${className}`}
    >
      {/* Header with Title, Stats, Link to /honor, and JSON Export */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#18213D] gap-3">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono tracking-widest uppercase text-[#D4A84B]">
            <ScrollText className="w-4 h-4 text-[#D4A84B]" />
            <span>{title || 'Achievement History · 達成記録'}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            <span className="font-mono text-sm sm:text-base font-bold text-[#F4EFE3] tabular-nums">
              {totalDeeds} {totalDeeds === 1 ? 'DEED' : 'DEEDS'}
            </span>
            <span className="text-[#8E9BB5] font-mono text-xs">·</span>
            <span className="font-mono text-xs sm:text-sm font-bold text-[#D4A84B] tabular-nums">
              +{totalPoints.toLocaleString()} PTS EARNED
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportJson}
            className="px-3 py-1.5 rounded-xl bg-[#151B38] hover:bg-[#D4A84B] border border-[#D4A84B]/40 text-[#D4A84B] hover:text-[#0A0A0F] font-mono text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer shadow-sm"
            title="Download your raw achievements history as JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export history (JSON)</span>
          </button>

          {page !== 'honor' && (
            <Link
              to="/honor"
              className="px-3 py-1.5 rounded-xl bg-[#0A0A0F] hover:bg-[#151B38] border border-[#18213D] hover:border-[#D4A84B] text-[#F4EFE3] font-mono text-xs transition-colors flex items-center space-x-1"
            >
              <span>View all honor activity</span>
              <span className="text-[#D4A84B]">➔</span>
            </Link>
          )}
        </div>
      </div>

      {/* Related Badges Row */}
      {pageBadges.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] font-mono uppercase tracking-widest text-[#8E9BB5] block">
            AFFILIATED WARRIOR CRESTS
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 font-mono text-xs">
            {pageBadges.map((badge) => {
              const unlockText = badge.unlocked
                ? badge.unlockedAt
                  ? `Unlocked ${new Date(badge.unlockedAt).toLocaleDateString([], {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}`
                  : 'Unlocked earlier'
                : badge.requirementText;

              return (
                <div
                  key={badge.id}
                  className={`p-3 rounded-xl border flex items-center space-x-3 transition-colors ${
                    badge.unlocked
                      ? 'bg-[#151B38]/80 border-[#D4A84B] shadow-[0_0_12px_rgba(212,168,75,0.18)]'
                      : 'bg-[#0A0A0F]/60 border-[#18213D] opacity-70'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-[#0A0A0F] border border-[#18213D] shrink-0">
                    <Shield
                      className={`w-4 h-4 ${badge.unlocked ? 'text-[#D4A84B]' : 'text-[#8E9BB5]'}`}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className={`font-serif font-bold text-xs truncate ${
                          badge.unlocked ? 'text-[#F4EFE3]' : 'text-[#8E9BB5]'
                        }`}
                      >
                        {badge.name}
                      </span>
                      <span className="font-kanji text-[10px] text-[#D4A84B] shrink-0">
                        {badge.kanji}
                      </span>
                    </div>
                    <span
                      className={`text-[10px] block truncate mt-0.5 ${
                        badge.unlocked ? 'text-[#34D399] font-bold' : 'text-[#8E9BB5]'
                      }`}
                    >
                      {unlockText}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter Chips Bar */}
      <div className="flex flex-wrap items-center gap-1.5 font-mono text-xs">
        <span className="text-[10px] uppercase text-[#8E9BB5] mr-1 flex items-center space-x-1">
          <Filter className="w-3 h-3 text-[#D4A84B]" />
          <span>Filter:</span>
        </span>
        {filterOptions.map((opt) => (
          <button
            key={opt}
            type="button"
            onClick={() => {
              setFilter(opt);
              setVisibleLimit(10);
            }}
            className={`px-3 py-1 rounded-lg border transition-all cursor-pointer ${
              filter === opt
                ? 'bg-[#D4A84B] text-[#0A0A0F] border-[#D4A84B] font-bold shadow-[0_0_10px_rgba(212,168,75,0.3)]'
                : 'bg-[#0A0A0F] border-[#18213D] text-[#8E9BB5] hover:text-[#F4EFE3] hover:border-[#D4A84B]/40'
            }`}
          >
            {opt}
          </button>
        ))}
        <span className="ml-auto text-[10px] text-[#8E9BB5] tabular-nums">
          Showing {Math.min(visibleLimit, filteredEntries.length)} of {filteredEntries.length} deeds
        </span>
      </div>

      {/* Timeline List Grouped by Month */}
      {filteredEntries.length === 0 ? (
        <div className="p-8 rounded-xl bg-[#0A0A0F]/70 border border-[#18213D] text-center space-y-2">
          <Compass className="w-8 h-8 text-[#D4A84B]/60 mx-auto" />
          <h4 className="font-serif text-base text-[#F4EFE3] font-semibold">No Deeds Recorded Yet</h4>
          <p className="font-mono text-xs text-[#8E9BB5] max-w-md mx-auto">{emptyHint}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {groupedByMonth.map((group) => (
            <div key={group.monthKey} className="space-y-3">
              {/* Month Header Banner */}
              <div className="flex items-center space-x-2 pb-1 border-b border-[#18213D]">
                <Calendar className="w-3.5 h-3.5 text-[#D4A84B]" />
                <span className="font-mono text-xs font-bold text-[#D4A84B] uppercase tracking-wider">
                  {group.monthLabel}
                </span>
                <span className="text-[10px] font-mono text-[#8E9BB5]">
                  ({group.entries.length} deeds)
                </span>
              </div>

              {/* Vertical Timeline Items */}
              <div className="relative pl-6 space-y-3 border-l-2 border-[#18213D] ml-2">
                {group.entries.map((entry) => {
                  const entryDate = new Date(entry.timestamp);
                  const timeFormatted = !isNaN(entryDate.getTime())
                    ? entryDate.toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : entry.timestamp;

                  return (
                    <div key={entry.id} className="relative group">
                      {/* Timeline dot */}
                      <span className="absolute -left-[31px] top-3 w-3 h-3 rounded-full bg-[#D4A84B] border-2 border-[#0A0A0F] shadow-[0_0_8px_rgba(212,168,75,0.6)]" />

                      <div className="p-3.5 sm:p-4 rounded-xl bg-[#0A0A0F]/90 border border-[#18213D] hover:border-[#D4A84B]/60 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase font-bold bg-[#151B38] text-[#D4A84B] border border-[#D4A84B]/30">
                              {entry.category || entry.type.replace('_', ' ')}
                            </span>
                            <span className="text-[10px] font-mono text-[#8E9BB5]">
                              {timeFormatted}
                            </span>
                          </div>

                          <h5 className="font-serif text-sm font-bold text-[#F4EFE3] truncate pt-0.5">
                            {entry.refName || entry.label}
                          </h5>

                          {/* Extra Metadata Badges */}
                          <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono text-[#8E9BB5] pt-0.5 tabular-nums">
                            {entry.meta?.eventDateIso && (
                              <span>
                                Event Date:{' '}
                                <strong className="text-[#F4EFE3]">
                                  {new Date(entry.meta.eventDateIso).toLocaleDateString()}
                                </strong>
                              </span>
                            )}
                            {typeof entry.meta?.distanceKm === 'number' && (
                              <span>
                                Distance:{' '}
                                <strong className="text-[#F4EFE3]">
                                  {entry.meta.distanceKm.toFixed(1)} km
                                </strong>
                              </span>
                            )}
                            {typeof entry.meta?.honorScore === 'number' && (
                              <span>
                                Honor Score:{' '}
                                <strong className="text-[#D4A84B]">
                                  {entry.meta.honorScore}/100
                                </strong>
                              </span>
                            )}
                            {typeof entry.meta?.bortleClass === 'number' && (
                              <span>
                                Bortle:{' '}
                                <strong className="text-[#F4EFE3]">
                                  Class {entry.meta.bortleClass}
                                </strong>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Points badge */}
                        <div className="shrink-0 self-start sm:self-center font-mono">
                          <span className="px-3 py-1 rounded-lg bg-[#D4A84B]/15 border border-[#D4A84B] text-[#D4A84B] font-bold text-xs tabular-nums">
                            +{entry.points} PTS
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Show More Pagination Button (10 items at a time) */}
          {visibleLimit < filteredEntries.length && (
            <div className="pt-2 flex justify-center">
              <button
                type="button"
                onClick={() => setVisibleLimit((prev) => prev + 10)}
                className="px-5 py-2 rounded-xl bg-[#151B38] hover:bg-[#D4A84B] border border-[#D4A84B]/50 text-[#D4A84B] hover:text-[#0A0A0F] font-mono text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Show 10 More Deeds ({filteredEntries.length - visibleLimit} remaining)
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
