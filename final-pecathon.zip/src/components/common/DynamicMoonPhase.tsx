import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import {
  getLunarPhase,
  fetchMoonPhaseApiData,
  LunarPhaseInfo,
  MoonPhaseApiResponse,
  DEFAULT_OBSERVATORY_COORDS,
} from '../../utils/lunarCycle';
import {
  Sparkles,
  Clock,
  RotateCcw,
  RefreshCw,
  Compass,
  MapPin,
  ArrowUpRight,
  ArrowDownRight,
  Radio,
  X,
} from 'lucide-react';
import { playSuzuChime } from '../../utils/soundEngine';

interface DynamicMoonPhaseProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showDetailsPopover?: boolean;
  compactMobile?: boolean;
  routeKey?: string;
}

export const DynamicMoonPhase: React.FC<DynamicMoonPhaseProps> = ({
  className = '',
  showDetailsPopover = true,
  routeKey,
}) => {
  const [isSimulatingOffset, setIsSimulatingOffset] = useState<boolean>(false);
  const [offsetDays, setOffsetDays] = useState<number>(0);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [isClosing, setIsClosing] = useState<boolean>(false);
  const [panelTop, setPanelTop] = useState<number>(64);

  // Live Moon Phase API State
  const [apiData, setApiData] = useState<MoonPhaseApiResponse | null>(null);
  const [isSyncingApi, setIsSyncingApi] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [observerCoords, setObserverCoords] = useState<{
    lat: number;
    lon: number;
    label: string;
    isCustomGps: boolean;
  }>({
    lat: DEFAULT_OBSERVATORY_COORDS.lat,
    lon: DEFAULT_OBSERVATORY_COORDS.lon,
    label: DEFAULT_OBSERVATORY_COORDS.label,
    isCustomGps: false,
  });
  const [locatingGps, setLocatingGps] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const popoverRef = useRef<HTMLDivElement | null>(null);

  const isCalmOrReduced = useCallback(() => {
    if (typeof window === 'undefined') return false;
    if (document.documentElement.dataset.calm === 'true') return true;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }, []);

  const updatePanelPosition = useCallback(() => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPanelTop(Math.round(rect.bottom + 8));
    }
  }, []);

  const triggerClose = useCallback(() => {
    if (isCalmOrReduced()) {
      setPopoverOpen(false);
      setIsClosing(false);
      buttonRef.current?.focus();
      return;
    }
    setIsClosing(true);
    setTimeout(() => {
      setPopoverOpen(false);
      setIsClosing(false);
      buttonRef.current?.focus();
    }, 250);
  }, [isCalmOrReduced]);

  const handleTogglePopover = () => {
    if (!showDetailsPopover) return;
    if (popoverOpen) {
      triggerClose();
    } else {
      updatePanelPosition();
      setIsClosing(false);
      setPopoverOpen(true);
    }
  };

  const syncLunarApi = useCallback(
    async (lat: number, lon: number, label: string, targetDate?: Date) => {
      setIsSyncingApi(true);
      try {
        const result = await fetchMoonPhaseApiData(lat, lon, targetDate, label);
        setApiData(result);
        setLastSyncTime(new Date());
      } catch (_err) {
        // Keep fallback SunCalc ephemeris active if network request fails
      } finally {
        setIsSyncingApi(false);
      }
    },
    []
  );

  // Initial API fetch & 60-second live refresh
  useEffect(() => {
    const targetDate = isSimulatingOffset
      ? new Date(Date.now() + offsetDays * 86400000)
      : undefined;
    syncLunarApi(observerCoords.lat, observerCoords.lon, observerCoords.label, targetDate);

    if (!isSimulatingOffset) {
      const apiTimer = setInterval(() => {
        syncLunarApi(observerCoords.lat, observerCoords.lon, observerCoords.label);
      }, 60000);
      return () => clearInterval(apiTimer);
    }
  }, [
    observerCoords.lat,
    observerCoords.lon,
    observerCoords.label,
    isSimulatingOffset,
    offsetDays,
    syncLunarApi,
  ]);

  // Real-time 1-second ticker so Moon Phase & Full Moon countdown update live
  useEffect(() => {
    const timer = setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const effectiveDate = new Date(nowMs + offsetDays * 86400000);
  const phaseInfo: LunarPhaseInfo = getLunarPhase(
    effectiveDate,
    observerCoords.lat,
    observerCoords.lon,
    apiData
  );

  // Recalculate position on window resize
  useEffect(() => {
    if (!popoverOpen) return;
    updatePanelPosition();
    const handleResize = () => updatePanelPosition();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [popoverOpen, updatePanelPosition]);

  // Close on window scroll beyond 80px
  useEffect(() => {
    if (!popoverOpen) return;
    const initialScrollY = window.scrollY;
    const handleScroll = () => {
      if (Math.abs(window.scrollY - initialScrollY) > 80) {
        triggerClose();
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [popoverOpen, triggerClose]);

  // Close popover when clicking outside or pressing Escape
  useEffect(() => {
    if (!popoverOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      const isInsideButton = buttonRef.current && buttonRef.current.contains(target);
      const isInsidePopover = popoverRef.current && popoverRef.current.contains(target);
      if (!isInsideButton && !isInsidePopover) {
        triggerClose();
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        triggerClose();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [popoverOpen, triggerClose]);

  // Close immediately on route change
  const prevRouteRef = useRef(routeKey);
  useEffect(() => {
    if (prevRouteRef.current !== routeKey) {
      prevRouteRef.current = routeKey;
      if (popoverOpen) {
        setPopoverOpen(false);
        setIsClosing(false);
      }
    }
  }, [routeKey, popoverOpen]);

  useEffect(() => {
    const handlePopState = () => {
      if (popoverOpen) {
        setPopoverOpen(false);
        setIsClosing(false);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [popoverOpen]);

  const handleSetDayOffset = (daysDelta: number) => {
    playSuzuChime();
    setIsSimulatingOffset(true);
    setOffsetDays(Number(daysDelta.toFixed(1)));
  };

  const resetToLiveRealTime = () => {
    playSuzuChime();
    setIsSimulatingOffset(false);
    setOffsetDays(0);
    setNowMs(Date.now());
    syncLunarApi(observerCoords.lat, observerCoords.lon, observerCoords.label);
  };

  const handleManualApiRefresh = () => {
    playSuzuChime();
    const targetDate = isSimulatingOffset
      ? new Date(Date.now() + offsetDays * 86400000)
      : undefined;
    syncLunarApi(observerCoords.lat, observerCoords.lon, observerCoords.label, targetDate);
  };

  const [gpsFallbackNotice, setGpsFallbackNotice] = useState<string | null>(null);

  const handleToggleObserverGps = () => {
    playSuzuChime();
    if (observerCoords.isCustomGps) {
      setObserverCoords({
        lat: DEFAULT_OBSERVATORY_COORDS.lat,
        lon: DEFAULT_OBSERVATORY_COORDS.lon,
        label: DEFAULT_OBSERVATORY_COORDS.label,
        isCustomGps: false,
      });
      setGpsFallbackNotice(null);
      return;
    }

    if (!navigator.geolocation) {
      setObserverCoords({
        lat: DEFAULT_OBSERVATORY_COORDS.lat,
        lon: DEFAULT_OBSERVATORY_COORDS.lon,
        label: DEFAULT_OBSERVATORY_COORDS.label,
        isCustomGps: false,
      });
      setGpsFallbackNotice('Using Chandigarh. Allow location or search a city.');
      return;
    }
    setLocatingGps(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(4));
        const lon = Number(pos.coords.longitude.toFixed(4));
        const ns = lat >= 0 ? 'N' : 'S';
        const ew = lon >= 0 ? 'E' : 'W';
        setObserverCoords({
          lat,
          lon,
          label: `Observer GPS (${Math.abs(lat).toFixed(2)}°${ns}, ${Math.abs(lon).toFixed(2)}°${ew})`,
          isCustomGps: true,
        });
        setGpsFallbackNotice(null);
        setLocatingGps(false);
      },
      () => {
        setObserverCoords({
          lat: DEFAULT_OBSERVATORY_COORDS.lat,
          lon: DEFAULT_OBSERVATORY_COORDS.lon,
          label: DEFAULT_OBSERVATORY_COORDS.label,
          isCustomGps: false,
        });
        setGpsFallbackNotice('Using Chandigarh. Allow location or search a city.');
        setLocatingGps(false);
      },
      { timeout: 6000 }
    );
  };

  const litPath = phaseInfo.svgTerminatorPath(12, 12, 10);
  const buttonAria = `Moon phase: ${phaseInfo.englishName}, ${phaseInfo.illuminationExact}% illuminated. ${
    popoverOpen ? 'Close details' : 'Open details'
  }`;
  const buttonTooltip = `Moon phase: ${phaseInfo.englishName}, ${phaseInfo.illuminationExact}% illuminated. Open details`;

  return (
    <div className={`relative inline-block ${className}`} ref={containerRef}>
      {/* 40x40px Circular Moon Phase Badge (No text inside) */}
      <button
        ref={buttonRef}
        type="button"
        onClick={handleTogglePopover}
        className={`w-10 h-10 rounded-full bg-[#0E1326] border transition-all duration-200 cursor-pointer flex items-center justify-center relative shrink-0 p-0 ${
          popoverOpen
            ? 'border-[#D4A84B] shadow-[0_0_15px_rgba(212,168,75,0.4)]'
            : 'border-[#D4A84B] hover:shadow-[0_0_10px_rgba(212,168,75,0.25)]'
        }`}
        aria-label={buttonAria}
        title={buttonTooltip}
        aria-expanded={popoverOpen}
        aria-controls={popoverOpen ? 'tsukuyomi-moon-panel' : undefined}
      >
        <div className="relative flex items-center justify-center">
          <svg
            width={24}
            height={24}
            viewBox="0 0 24 24"
            className="filter drop-shadow-[0_0_6px_rgba(244,239,227,0.5)] transition-transform duration-300 hover:scale-110"
          >
            <defs>
              <linearGradient id="navMoonGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFFDF5" />
                <stop offset="70%" stopColor="#F4EFE3" />
                <stop offset="100%" stopColor="#D4A84B" />
              </linearGradient>

              <radialGradient id="navDarkSide" cx="50%" cy="50%" r="50%">
                <stop offset="60%" stopColor="#0B0E1B" />
                <stop offset="100%" stopColor="#05070E" />
              </radialGradient>

              <clipPath id="navMoonClip">
                <circle cx="12" cy="12" r="10" />
              </clipPath>
            </defs>

            {/* Dark unlit lunar disc (base) */}
            <circle
              cx="12"
              cy="12"
              r="10"
              fill="url(#navDarkSide)"
              stroke="#D4A84B"
              strokeWidth="0.85"
              strokeOpacity="0.55"
            />

            {/* Faint craters on dark side */}
            <g clipPath="url(#navMoonClip)" opacity="0.25">
              <circle cx={9} cy={10} r={2.5} fill="#182038" />
              <circle cx={14.5} cy={15.5} r={3} fill="#182038" />
            </g>

            {/* Dynamic Illuminated Phase Path */}
            {litPath ? (
              <path
                d={litPath}
                fill="url(#navMoonGlow)"
                className="transition-all duration-300 ease-out"
              />
            ) : (
              <circle
                cx="12"
                cy="12"
                r="9.5"
                fill="none"
                stroke="#D4A84B"
                strokeWidth="0.75"
                strokeDasharray="2 2"
                opacity="0.6"
              />
            )}

            {/* Rim highlight */}
            <circle
              cx="12"
              cy="12"
              r="10"
              fill="none"
              stroke="#F4EFE3"
              strokeWidth="0.5"
              strokeOpacity="0.35"
            />
          </svg>

          {/* Live API Telemetry Status Dot at bottom-right */}
          <span
            className={`absolute -bottom-1 -right-1 w-2.5 h-2.5 rounded-full border border-[#0A0A0F] ${
              isSimulatingOffset
                ? 'bg-amber-400'
                : apiData
                  ? 'bg-emerald-400'
                  : 'bg-[#D4A84B]'
            }`}
          />
        </div>
      </button>

      {/* Interactive Lunar Ephemeris Popover (Portaled to document.body, transforms out of circle) */}
      {showDetailsPopover && popoverOpen && typeof document !== 'undefined' && createPortal(
        <div
          id="tsukuyomi-moon-panel"
          ref={popoverRef}
          style={{
            position: 'fixed',
            top: `${panelTop}px`,
            right: '1rem',
            width: 'min(22rem, calc(100vw - 2rem))',
            maxHeight: 'calc(100vh - 6rem)',
            overflowY: 'auto',
            zIndex: 70,
            transformOrigin: 'top right',
          }}
          className={`bg-[#0B0F1F]/98 border border-[#D4A84B] rounded-2xl p-5 shadow-[0_0_40px_rgba(212,168,75,0.35)] backdrop-blur-xl text-left space-y-4 ${
            isClosing ? 'moon-panel-close' : 'moon-panel-open'
          }`}
          role="dialog"
          aria-modal="false"
          aria-labelledby="moon-phase-panel-title"
        >
          {/* Header with Circle anchored in top-right corner + Close X */}
          <div className="flex items-start justify-between border-b border-[#18213D] pb-3 gap-2">
            <div className="space-y-0.5 min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-kanji text-xl text-[#D4A84B] font-bold">
                  {phaseInfo.japaneseName}
                </span>
                <span className="text-[10px] font-mono tracking-widest text-[#D4A84B] uppercase">
                  · {phaseInfo.romaji}
                </span>
              </div>
              <h4 id="moon-phase-panel-title" className="font-serif text-lg font-bold text-[#F4EFE3] truncate">
                {phaseInfo.englishName}
              </h4>
              <div className="flex items-center space-x-1.5 pt-0.5">
                <span
                  className={`text-[10px] font-mono flex items-center space-x-1 ${
                    isSimulatingOffset ? 'text-amber-400' : 'text-emerald-400'
                  }`}
                >
                  <Radio className="w-3 h-3 animate-pulse shrink-0" />
                  <span className="truncate">
                    {isSimulatingOffset
                      ? `SIMULATED OFFSET (${offsetDays >= 0 ? '+' : ''}${offsetDays}d)`
                      : phaseInfo.usnoVerified
                        ? 'USNO + SUNCALC LIVE API'
                        : 'SUNCALC LIVE EPHEMERIS'}
                  </span>
                </span>
              </div>
            </div>

            {/* Preserved Circle disc at top-right corner + controls + Close X */}
            <div className="flex items-center space-x-1.5 shrink-0">
              <div className="flex flex-col space-y-1">
                <button
                  type="button"
                  onClick={handleManualApiRefresh}
                  className="p-1 rounded-lg bg-[#151B38] hover:bg-[#D4A84B] text-[#D4A84B] hover:text-[#0A0A0F] transition-colors cursor-pointer"
                  title="Sync real-time Moon Phase API telemetry"
                  aria-label="Sync real-time Moon Phase API telemetry"
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncingApi ? 'animate-spin' : ''}`} />
                </button>
                <button
                  type="button"
                  onClick={handleToggleObserverGps}
                  className={`p-1 rounded-lg transition-colors cursor-pointer ${
                    observerCoords.isCustomGps
                      ? 'bg-[#D4A84B] text-[#0A0A0F]'
                      : 'bg-[#151B38] hover:bg-[#D4A84B] text-[#8E9BB5] hover:text-[#0A0A0F]'
                  }`}
                  title={
                    observerCoords.isCustomGps
                      ? 'Reset to Chandigarh Observatory coordinates'
                      : 'Use my GPS coordinates for local Moon altitude & rise/set times'
                  }
                  aria-label="Toggle Observer GPS Coordinates"
                >
                  <MapPin className={`w-3 h-3 ${locatingGps ? 'animate-bounce' : ''}`} />
                </button>
              </div>

              {/* Top-right corner moon circle */}
              <div
                className="w-10 h-10 rounded-full border border-[#D4A84B] bg-[#0E1326] flex items-center justify-center relative shadow-[0_0_12px_rgba(212,168,75,0.35)] shrink-0"
                title={`${phaseInfo.englishName} (${phaseInfo.japaneseName})`}
              >
                <svg width={24} height={24} viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10" fill="url(#navDarkSide)" stroke="#D4A84B" strokeWidth="0.85" />
                  {phaseInfo.svgTerminatorPath(12, 12, 10) ? (
                    <path d={phaseInfo.svgTerminatorPath(12, 12, 10)!} fill="url(#navMoonGlow)" />
                  ) : null}
                </svg>
                <span
                  className={`absolute bottom-0 right-0 w-2 h-2 rounded-full border border-[#0A0A0F] ${
                    isSimulatingOffset ? 'bg-amber-400' : apiData ? 'bg-emerald-400' : 'bg-[#D4A84B]'
                  }`}
                />
              </div>

              {/* Close X */}
              <button
                type="button"
                onClick={triggerClose}
                className="w-8 h-8 rounded-full bg-[#151B38] hover:bg-[#B3202A] text-[#8E9BB5] hover:text-[#F4EFE3] transition-colors flex items-center justify-center cursor-pointer ml-1"
                aria-label="Close details"
                title="Close details"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Observer Coordinates Bar */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[10px] font-mono bg-[#070A14] px-2.5 py-1.5 rounded-lg border border-[#18213D] text-[#8E9BB5]">
              <span className="flex items-center space-x-1 truncate">
                <Compass className="w-3 h-3 text-[#D4A84B] shrink-0" />
                <span className="truncate">{phaseInfo.locationLabel}</span>
              </span>
              {lastSyncTime && (
                <span className="text-[9px] text-[#D4A84B]/80 shrink-0 ml-2">
                  {lastSyncTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}
            </div>
            {gpsFallbackNotice && (
              <div className="text-[10px] font-mono text-[#D4A84B] px-1">
                {gpsFallbackNotice}
              </div>
            )}
          </div>

          {/* Real-Time Topocentric & Orbital Telemetry Grid */}
          <div className="grid grid-cols-2 gap-2 font-mono">
            {/* Illumination & Lunar Age */}
            <div className="p-2.5 rounded-xl bg-[#070A14] border border-[#18213D] space-y-1">
              <div className="flex items-center justify-between text-[9px] text-[#8E9BB5] uppercase">
                <span>Illumination</span>
                <span className="text-[#D4A84B]">{phaseInfo.isWaxing ? 'WAXING' : 'WANING'}</span>
              </div>
              <div className="text-sm font-bold text-[#F4EFE3] tabular-nums">
                {phaseInfo.illuminationExact}%
              </div>
              <div className="w-full h-1.5 rounded-full bg-[#141B33] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#D4A84B] to-[#FFFDF5]"
                  style={{ width: `${Math.max(3, phaseInfo.illuminationPercent)}%` }}
                />
              </div>
              <div className="text-[9px] text-[#8E9BB5] tabular-nums">
                Age: {phaseInfo.lunarAgeDays} / 29.5d
              </div>
            </div>

            {/* Orbital Distance & Limb Angle */}
            <div className="p-2.5 rounded-xl bg-[#070A14] border border-[#18213D] space-y-1">
              <div className="flex items-center justify-between text-[9px] text-[#8E9BB5] uppercase">
                <span>Lunar Distance</span>
                <span className="text-[#D4A84B]">ORBIT</span>
              </div>
              <div className="text-sm font-bold text-[#F4EFE3] tabular-nums">
                {phaseInfo.distanceKm.toLocaleString()} km
              </div>
              <div className="text-[9px] text-[#8E9BB5] tabular-nums">
                Limb Angle: {phaseInfo.brightLimbAngleDeg}°
              </div>
              <div className="text-[9px] text-[#8E9BB5] tabular-nums">
                Parallactic: {phaseInfo.parallacticAngleDeg}°
              </div>
            </div>

            {/* Topocentric Altitude & Azimuth */}
            <div className="p-2.5 rounded-xl bg-[#070A14] border border-[#18213D] space-y-1">
              <div className="flex items-center justify-between text-[9px] text-[#8E9BB5] uppercase">
                <span>Sky Position</span>
                <span
                  className={
                    phaseInfo.isAboveHorizon ? 'text-emerald-400 font-bold' : 'text-[#8E9BB5]'
                  }
                >
                  {phaseInfo.isAboveHorizon ? 'VISIBLE' : 'BELOW HORIZON'}
                </span>
              </div>
              <div className="text-xs font-bold text-[#F4EFE3] tabular-nums">
                {phaseInfo.altitudeDeg}° ALT · {phaseInfo.azimuthDeg}° {phaseInfo.compassDirection}
              </div>
              <div className="text-[9px] text-[#8E9BB5] tabular-nums">
                Meridian Transit: {phaseInfo.transitFormatted}
              </div>
            </div>

            {/* Moonrise & Moonset */}
            <div className="p-2.5 rounded-xl bg-[#070A14] border border-[#18213D] space-y-1">
              <div className="flex items-center justify-between text-[9px] text-[#8E9BB5] uppercase">
                <span>Horizon Ephemeris</span>
                <span className="text-[#D4A84B]">LOCAL</span>
              </div>
              <div className="flex items-center justify-between text-[11px] font-bold text-[#F4EFE3] tabular-nums">
                <span className="flex items-center space-x-0.5">
                  <ArrowUpRight className="w-3 h-3 text-[#D4A84B]" />
                  <span>{phaseInfo.moonriseFormatted}</span>
                </span>
                <span className="flex items-center space-x-0.5">
                  <ArrowDownRight className="w-3 h-3 text-[#8E9BB5]" />
                  <span>{phaseInfo.moonsetFormatted}</span>
                </span>
              </div>
              <div className="text-[9px] text-[#8E9BB5]">
                Rise & Set Times
              </div>
            </div>
          </div>

          {/* Live Countdown to Next Full Moon */}
          <div className="p-3 rounded-xl bg-[#070A14] border border-[#D4A84B]/40 space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-mono text-[#D4A84B] font-bold">
              <span className="flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>COUNTDOWN TO NEXT FULL MOON · 望月</span>
              </span>
              <span className="tabular-nums">{phaseInfo.daysUntilNextFull} DAYS</span>
            </div>

            <div className="grid grid-cols-4 gap-2 pt-1 font-mono text-center tabular-nums">
              <div className="bg-[#0E1326] border border-[#18213D] rounded-lg py-1.5">
                <span className="text-base font-bold text-[#F4EFE3] block">
                  {phaseInfo.fullMoonCountdown.days}
                </span>
                <span className="text-[9px] text-[#8E9BB5] uppercase">Days</span>
              </div>
              <div className="bg-[#0E1326] border border-[#18213D] rounded-lg py-1.5">
                <span className="text-base font-bold text-[#F4EFE3] block">
                  {String(phaseInfo.fullMoonCountdown.hours).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-[#8E9BB5] uppercase">Hours</span>
              </div>
              <div className="bg-[#0E1326] border border-[#18213D] rounded-lg py-1.5">
                <span className="text-base font-bold text-[#F4EFE3] block">
                  {String(phaseInfo.fullMoonCountdown.minutes).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-[#8E9BB5] uppercase">Mins</span>
              </div>
              <div className="bg-[#0E1326] border border-[#18213D] rounded-lg py-1.5">
                <span className="text-base font-bold text-[#D4A84B] block">
                  {String(phaseInfo.fullMoonCountdown.seconds).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-[#8E9BB5] uppercase">Secs</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono text-[#8E9BB5] pt-0.5 tabular-nums">
              <span>
                Next Full Moon:{' '}
                <strong className="text-[#F4EFE3]">
                  {phaseInfo.nextFullMoonDate.toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </strong>
              </span>
              <span>Next New Moon: {phaseInfo.daysUntilNextNew}d</span>
            </div>
          </div>

          {/* Upcoming USNO Primary Phases (when returned by API) */}
          {phaseInfo.upcomingPhases.length > 0 && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[9px] font-mono text-[#8E9BB5] uppercase">
                <span>Upcoming Primary Phases (USNO Ephemeris)</span>
                <span className="text-[#D4A84B]">UTC</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 font-mono text-[10px]">
                {phaseInfo.upcomingPhases.slice(0, 4).map((up, idx) => (
                  <div
                    key={`${up.phase}-${idx}`}
                    className="px-2 py-1 rounded bg-[#070A14] border border-[#18213D] flex items-center justify-between"
                  >
                    <span className="text-[#F4EFE3] font-semibold truncate">{up.phase}</span>
                    <span className="text-[#D4A84B] text-[9px] shrink-0 ml-1">{up.dateStr.slice(5)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Samurai Celestial Lore */}
          <div className="p-3 rounded-xl bg-[#12182E]/80 border border-[#D4A84B]/30 space-y-1">
            <div className="flex items-center space-x-1 text-[11px] font-mono text-[#D4A84B] font-bold">
              <Sparkles className="w-3.5 h-3.5 text-[#D4A84B]" />
              <span>CELESTIAL WISDOM · 天文の教え</span>
            </div>
            <p className="text-xs text-[#F4EFE3]/90 italic font-serif leading-relaxed">
              "{phaseInfo.samuraiLore}"
            </p>
          </div>

          {/* Interactive Lunar Cycle Scrubber & Presets */}
          <div className="pt-2 border-t border-[#18213D] space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-[#8E9BB5]">
              <span>SYNODIC CYCLE EXPLORER</span>
              {isSimulatingOffset && (
                <button
                  type="button"
                  onClick={resetToLiveRealTime}
                  className="text-[#D4A84B] hover:text-[#F4EFE3] flex items-center space-x-1 cursor-pointer font-bold"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Return to Live API</span>
                </button>
              )}
            </div>

            <input
              type="range"
              min="-15"
              max="15"
              step="0.5"
              value={offsetDays}
              onChange={(e) => handleSetDayOffset(Number(e.target.value))}
              className="w-full accent-[#D4A84B] cursor-pointer h-1.5 bg-[#151B38] rounded-lg"
              aria-label="Simulate lunar cycle days offset"
            />

            <div className="grid grid-cols-4 gap-1.5 text-[10px] font-mono">
              <button
                type="button"
                onClick={() => handleSetDayOffset(-phaseInfo.lunarAgeDays)}
                className="p-1.5 rounded bg-[#070A14] border border-[#18213D] hover:border-[#D4A84B] text-[#8E9BB5] hover:text-[#F4EFE3] transition-colors cursor-pointer"
              >
                🌑 New
              </button>
              <button
                type="button"
                onClick={() => handleSetDayOffset(7.4 - phaseInfo.lunarAgeDays)}
                className="p-1.5 rounded bg-[#070A14] border border-[#18213D] hover:border-[#D4A84B] text-[#8E9BB5] hover:text-[#F4EFE3] transition-colors cursor-pointer"
              >
                🌓 1st Qtr
              </button>
              <button
                type="button"
                onClick={() => handleSetDayOffset(14.77 - phaseInfo.lunarAgeDays)}
                className="p-1.5 rounded bg-[#070A14] border border-[#18213D] hover:border-[#D4A84B] text-[#8E9BB5] hover:text-[#F4EFE3] transition-colors cursor-pointer"
              >
                🌕 Full
              </button>
              <button
                type="button"
                onClick={() => handleSetDayOffset(22.15 - phaseInfo.lunarAgeDays)}
                className="p-1.5 rounded bg-[#070A14] border border-[#18213D] hover:border-[#D4A84B] text-[#8E9BB5] hover:text-[#F4EFE3] transition-colors cursor-pointer"
              >
                🌗 3rd Qtr
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};
